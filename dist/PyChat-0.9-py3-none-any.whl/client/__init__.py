"""A package for client"""
# pylint: skip-file
__all__ = [
    'demo_client'
    ]
