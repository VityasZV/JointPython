"""A package for http server"""
# pylint: skip-file
__all__ = [
    'demo_server',
    'http_server',
    ]
